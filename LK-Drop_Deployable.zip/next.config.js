/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: { domains: ['localhost', 'lkdrop.com'] }
};
module.exports = nextConfig;